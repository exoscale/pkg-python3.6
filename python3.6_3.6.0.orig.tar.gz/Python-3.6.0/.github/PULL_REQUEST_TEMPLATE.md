## CPython Mirror

https://github.com/python/cpython is a cpython mirror repository. Pull requests
are not accepted on this repo and will be automatically closed.

### Submit patches at https://bugs.python.org

For additional information about contributing to CPython, see the
[developer's guide](https://docs.python.org/devguide/#contributing).
